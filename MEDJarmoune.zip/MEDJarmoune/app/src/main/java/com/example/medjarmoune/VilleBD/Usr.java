package com.example.medjarmoune.VilleBD;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "Usrs")
public class Usr {
    @PrimaryKey(autoGenerate = true)
    int uid;
    @ColumnInfo(name = "Name")
    String fullname;
    @ColumnInfo(name = "Ville")
    String ville;
    @ColumnInfo(typeAffinity = ColumnInfo.BLOB)
    byte[] image;

    public int getUid() {
        return uid;
    }

    public String getFullname() {
        return fullname;
    }

    public String getVille() {
        return ville;
    }

    public byte[] getImage() {
        return image;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public void setVille(String ville) {
        this.ville = ville;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

}
