package com.example.medjarmoune;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.medjarmoune.VilleBD.UserDAO;
import com.example.medjarmoune.VilleBD.UserDatabase;
import com.example.medjarmoune.VilleBD.VilleActivity;

public class ShowUsersActivity extends AppCompatActivity {

    RecyclerView recyclerView;

    UserDAO userDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_users);
        recyclerView=findViewById(R.id.userRecyclerView);

        userDAO= UserDatabase.getDBInstance(this).userdao();

        UserRecycler userRecycler =new UserRecycler(userDAO.getAllUsers());

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(userRecycler);

    }
        public  boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
    @SuppressLint("WrongConstant")
    public boolean onOptionsItemSelected(MenuItem item){

        switch (item.getItemId()){
            case R.id.item1:
                if (userDAO.getAllUsers().size()!=0) {
                    Toast.makeText(this , "A propos " , 1000).show();
                    startActivity(new Intent(this , alleraumap.class));
                } break;
            case R.id.item2:Toast.makeText(this,"Ajouter un etablissement",1000).show();
                startActivity(new Intent(this, VilleActivity.class));
                break;
            case R.id.item3:Toast.makeText(this,"supprimer un etablissement",1000).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
