package com.example.medjarmoune;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import com.example.medjarmoune.VilleBD.DataConverter;
import com.example.medjarmoune.VilleBD.Usr;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class UserRecycler extends RecyclerView.Adapter<UserViewHolder> {

    List<Usr> data;

    public UserRecycler(List<Usr> users){
        data=users;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup , int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.user_item_layout,viewGroup,false);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder , int position) {
        Usr usr =data.get(position);
        holder.imageView.setImageBitmap(DataConverter.convetByteArray2Image(usr.getImage()));
        holder.name.setText(usr.getFullname());
        holder.ville.setText(usr.getVille());
    }

    @Override
    public int getItemCount() {
        return data.size();
    }
}
