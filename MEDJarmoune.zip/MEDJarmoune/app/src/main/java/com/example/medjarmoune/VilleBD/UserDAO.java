package com.example.medjarmoune.VilleBD;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

@Dao
public interface UserDAO {
    @Query("Select * from Usrs")
    List<Usr>getAllUsers();
    @Insert
    void insertUsr(Usr usr);
    @Update
    void updateUsr(Usr usr);
    @Delete
    void deleteUsr(Usr usr);
}
