package com.example.medjarmoune;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class alleraumap extends AppCompatActivity {
    EditText lat;
    EditText longt;
    static double lati,longtu;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alleraumap);
        lat=findViewById(R.id.latitudee);
        longt=findViewById(R.id.Longitituee);

    }

    public void vermap(View view) {
       lati=Double.parseDouble(lat.getText().toString());
       longtu=Double.parseDouble(longt.getText().toString());
       startActivity(new Intent(this,MapsActivity.class));
    }
}
