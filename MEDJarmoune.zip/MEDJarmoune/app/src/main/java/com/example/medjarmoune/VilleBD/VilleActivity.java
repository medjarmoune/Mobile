package com.example.medjarmoune.VilleBD;
import com.example.medjarmoune.R;
import com.example.medjarmoune.ShowUsersActivity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Camera;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import android.os.Bundle;

public class VilleActivity extends AppCompatActivity {

    ImageView imageView;
    Bitmap bmpImage;
    EditText name,ville,pass;
    UserDAO userDAO;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ville);
        imageView=findViewById(R.id.userImage);
        bmpImage=null;
        name=findViewById(R.id.fullname);
        ville=findViewById(R.id.villeusr);
        pass=findViewById(R.id.usrpassword);

        userDAO=UserDatabase.getDBInstance(this).userdao();
    }
    final int CAMERA_INTENT =51;
    public void takePicture(View view) {
        Intent intent =new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager())!=null){
            startActivityForResult(intent, CAMERA_INTENT);
        }
    }
    @Override
    protected void onActivityResult(int requestCode , int resultCode , @Nullable Intent data) {
        super.onActivityResult(requestCode , resultCode , data);
        switch (requestCode){
            case CAMERA_INTENT:
                // if (requestCode == Activity.RESULT_OK) {
                bmpImage = (Bitmap) data.getExtras().get("data");
                if (bmpImage!=null){
                    imageView.setImageBitmap(bmpImage);
                }
                // }
                break;
        }
    }
    public void saveusrs(View view) {
        if (name.getText().toString().isEmpty()
                ||ville.getText().toString().isEmpty()||
                pass.getText().toString().isEmpty()){
            Toast.makeText(this,"user is missing",Toast.LENGTH_SHORT).show();
        }
        else {
            Usr user=new Usr();
            user.setFullname(name.getText().toString());
            user.setVille(ville.getText().toString());

            user.setImage(DataConverter.convertImage2ByteArray(bmpImage));
//            Double.parseDouble
            userDAO.insertUsr(user);
            int i=userDAO.getAllUsers().size();
            Toast.makeText(this,userDAO.getAllUsers().get(i-1)+" est enregistrer",Toast.LENGTH_SHORT).show();

        }
    }

    public void showsrs(View view) {
        startActivity(new Intent(this, ShowUsersActivity.class));
    }

}
